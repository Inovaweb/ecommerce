<?php
/*
Template Name: Home Page
*/
?>
<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<!DOCTYPE html>
<html <?php echo !is_rtl() ? 'dir="ltr" ' : ''; language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset') ?>" />
    <link href="<?php echo theme_get_image_path('images/2dc5949a4bc4338d98ac493a8271f598_favicon32x32.png'); ?>" rel="icon" type="image/x-icon" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
    <script>
    var themeHasJQuery = !!window.jQuery;
</script>
<script src="<?php echo get_bloginfo('template_url', 'display') . '/jquery.js?ver=' . wp_get_theme()->get('Version'); ?>"></script>
<script>
    window._$ = jQuery.noConflict(themeHasJQuery);
</script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="<?php echo get_bloginfo('template_url', 'display'); ?>/CloudZoom.js?ver=<?php echo wp_get_theme()->get('Version'); ?>" type="text/javascript"></script>
    
    <?php wp_head(); ?>
    
    <!--[if lte IE 9]>
    <link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_url', 'display') . '/style.ie.css?ver=' . wp_get_theme()->get('Version'); ?>" />
    <![endif]-->
</head>
<body <?php body_class(' bootstrap bd-body-1 bd-pagebackground'); ?>>
<header class=" bd-headerarea-1">
        <div class="container  bd-containereffect-15"><div class=" bd-layoutcontainer-9">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-layoutcolumn-col-28 
 col-lg-17
 col-sm-8">
    <div class="bd-layoutcolumn-28"><div class="bd-vertical-align-wrapper"><?php
    theme_topmenu_1();
?></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-36 
 col-lg-3
 col-sm-4">
    <div class="bd-layoutcolumn-36"><div class="bd-vertical-align-wrapper"><div class=" bd-customhtml-1 bd-tagstyles bd-custom-button">
    <div class="bd-container-inner bd-content-element">
        <?php
echo <<<'CUSTOM_CODE'
<p><a href="http://magnanatura.com" class="bd-button-56">PT</a>&nbsp;| <a href="http://magnanatura.com/en" class="bd-button-56">EN</a></p>
CUSTOM_CODE;
?>
    </div>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-35 
 col-lg-4
 col-sm-8">
    <div class="bd-layoutcolumn-35"><div class="bd-vertical-align-wrapper"><div class=" bd-customhtml-2 bd-tagstyles">
    <div class="bd-container-inner bd-content-element">
        <?php
echo <<<'CUSTOM_CODE'
<p><i class="icon-phone"></i> (+351) 911 015 388</p>
CUSTOM_CODE;
?>
    </div>
</div></div></div>
</div>
            </div>
        </div>
    </div>
</div></div>
	
		<div data-affix
     data-offset=""
     data-fix-at-screen="top"
     data-clip-at-control="top"
     
 data-enable-lg
     
 data-enable-md
     
 data-enable-sm
     
     class=" bd-affix-1"><div class=" bd-layoutbox-5 clearfix">
    <div class="bd-container-inner">
        <?php theme_logo_3(); ?>
	
		<?php
    if (theme_get_option('theme_use_default_menu')) {
        wp_nav_menu( array('theme_location' => 'primary-menu-2') );
    } else {
        theme_hmenu_2();
    }
?>
    </div>
</div>
</div>
</header>
	
		<div id="carousel-1" class="bd-slider bd-slider-1 bd-page-width  carousel slide bd-carousel-fade">
    

    
    <div class="bd-container-inner">

    

    <div class="bd-slides carousel-inner">
        <div class=" bd-slide-6 bd-slide item"
    
    
    >
    <div class="bd-container-inner">
        <div class="bd-container-inner-wrapper">
            
        </div>
    </div>
</div>
	
		<div class=" bd-slide-2 bd-slide item"
    
    
    >
    <div class="bd-container-inner">
        <div class="bd-container-inner-wrapper">
            
        </div>
    </div>
</div>
	
		<div class=" bd-slide-3 bd-slide item"
    
    
    >
    <div class="bd-container-inner">
        <div class="bd-container-inner-wrapper">
            
        </div>
    </div>
</div>
    </div>

    

    
    </div>

    

    <script type="text/javascript">
        /* <![CDATA[ */
        if ('undefined' !== typeof initSlider){
            initSlider(
                '.bd-slider-1',
                'bd-left-button',
                'bd-right-button',
                '.bd-carousel',
                '.bd-indicators',
                3600,
                "",
                true,
                true
            );
        }
        /* ]]> */
    </script>
</div>
	
		<div class=" bd-layoutcontainer-42">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-layoutcolumn-col-87 
 col-md-8">
    <div class="bd-layoutcolumn-87"><div class="bd-vertical-align-wrapper"><div class=" bd-textblock-9 bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
<a href="http://magnanatura.com/en/product-category/furniture/">FURNITURE</a>
CUSTOM_CODE;
?>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-137 
 col-md-8">
    <div class="bd-layoutcolumn-137"><div class="bd-vertical-align-wrapper"><div class=" bd-textblock-12 bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
<a href="http://magnanatura.com/en/product-category/decoration/">
    DECORATION</a>
CUSTOM_CODE;
?>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-141 
 col-md-8">
    <div class="bd-layoutcolumn-141"><div class="bd-vertical-align-wrapper"><div class=" bd-textblock-14 bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
<a href="http://magnanatura.com/en/product-category/covering/">WALL COVERING</a><br>
CUSTOM_CODE;
?>
</div></div></div>
</div>
            </div>
        </div>
    </div>
</div>
	
		<div data-smooth-scroll data-animation-time="250" class=" bd-smoothscroll-3"><a href="#" class=" bd-backtotop-1">
    <span class=" bd-icon-67"></span>
</a></div>
	
		<div class=" bd-animation-7 animated" data-animation-name="zoomIn"
                                    data-animation-event="scroll"
                                    data-animation-duration="1800ms"
                                    data-animation-delay="300ms"
                                    data-animation-infinited="false"
                                    >
<h2 class=" bd-textblock-16 bd-background-width bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
FROM PORTUGAL TO THE WORLD MAGNA NATURA PRODUCTS ARE AN AUTHENTIC JEWEL!<br>
CUSTOM_CODE;
?>
</h2>
</div>
	
		<div class="container  bd-containereffect-2"><div class=" bd-spacer-1 clearfix"></div></div>
	
		<div class=" bd-layoutbox-1 bd-background-width clearfix">
    <div class="bd-container-inner">
        <div class=" bd-layoutcontainer-13">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                    bd-row-auto-height
                    
 bd-row-align-middle
                ">
                <div class=" bd-layoutcolumn-col-52 
 col-sm-8">
    <div class="bd-layoutcolumn-52"><div class="bd-vertical-align-wrapper"><div class="container  bd-containereffect-6"><div class=" bd-hoverbox-1 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-70 bd-tagstyles">
    <div class=" bd-textgroup-1 bd-block-6">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-4  media-object " src="<?php echo theme_get_image_path('images/133ea19cc147228e3dd9b2e7d0785014_Urbem.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
URBEM
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'
<br>
CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-71 bd-tagstyles">
    <a href="http://magnanatura.com/en/products/furniture/urbem/" class=" bd-linkbutton-6 bd-button-39 bd-icon-4 bd-content-element"  
 title="URBEM" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-54 
 col-sm-8">
    <div class="bd-layoutcolumn-54"><div class="bd-vertical-align-wrapper"><div class=" bd-hoverbox-2 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-72 bd-tagstyles">
    <div class=" bd-textgroup-2 bd-block-7">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-6  media-object " src="<?php echo theme_get_image_path('images/55f97ba9389208972c5fe08f164b0cc8_mesacentro.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
AZZULAJ
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-73 bd-tagstyles">
    <a href="http://magnanatura.com/en/products/furniture/zzulaj/" class=" bd-linkbutton-7 bd-button-41 bd-icon-5 bd-content-element"  
 title="AZZULAJ" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-55 
 col-sm-8">
    <div class="bd-layoutcolumn-55"><div class="bd-vertical-align-wrapper"><div class=" bd-hoverbox-3 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-74 bd-tagstyles">
    <div class=" bd-textgroup-3 bd-block-11">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-7  media-object " src="<?php echo theme_get_image_path('images/c9d95e0cc1cd4328723dbaae51eb66f1_espelho2.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
MIRAGGE
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-75 bd-tagstyles">
    <a href="http://magnanatura.com/en/produto/miragge/" class=" bd-linkbutton-8 bd-button-43 bd-icon-13 bd-content-element"  
 title="MIRAGGE" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div></div></div>
</div>
            </div>
        </div>
    </div>
</div>
	
		<div class=" bd-layoutcontainer-16">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-layoutcolumn-col-72 
 col-lg-8
 col-md-8
 col-sm-8">
    <div class="bd-layoutcolumn-72"><div class="bd-vertical-align-wrapper"><div class=" bd-hoverbox-4 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-91 bd-tagstyles">
    <div class=" bd-textgroup-8 bd-block-18">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-2  media-object " src="<?php echo theme_get_image_path('images/a287576380a7ed550f0a69b793addb55_chairing.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
CHAIRING
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'
<br>
CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-92 bd-tagstyles">
    <a href="http://magnanatura.com/en/produto/chairing/" class=" bd-linkbutton-9 bd-button-47 bd-icon-42 bd-content-element"  
 title="CHAIRING" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-73 
 col-lg-8
 col-sm-8">
    <div class="bd-layoutcolumn-73"><div class="bd-vertical-align-wrapper"><div class=" bd-hoverbox-5 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-93 bd-tagstyles">
    <div class=" bd-textgroup-5 bd-block-15">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-9  media-object " src="<?php echo theme_get_image_path('images/3636f7067cfe9eba6926e1e787a7d8b1_Untitled.196.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
TRIBUS
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br>
CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-95 bd-tagstyles">
    <a href="http://magnanatura.com/en/produto/tribus/" class=" bd-linkbutton-10 bd-button-49 bd-icon-48 bd-content-element"  
 title="TRIBUS" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-74 
 col-lg-8
 col-sm-8">
    <div class="bd-layoutcolumn-74"><div class="bd-vertical-align-wrapper"><div class=" bd-hoverbox-8 bd-effect-zoom-rotateY">
  <div class="bd-slidesWrapper">
    <div class="bd-backSlide"><div class=" bd-container-117 bd-tagstyles">
    <div class=" bd-textgroup-7 bd-block-21">
    <div class="bd-container-inner">
        <div class="media">
            
 <img class="bd-imagestyles bd-imagelink-3  media-object " src="<?php echo theme_get_image_path('images/8a74654e33bf1f1a9bf15e43f9ca7e71_UNION.jpg'); ?>">
            <div class="media-body">
                
                    <h4 class="media-heading  bd-blockheader bd-tagstyles bd-content-element"><?php
echo <<<'CUSTOM_CODE'
UNIONE
CUSTOM_CODE;
?></h4>
                
                <div class=" bd-blockcontent bd-tagstyles bd-content-element">
                    <?php
echo <<<'CUSTOM_CODE'
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br>
CUSTOM_CODE;
?>
                </div>
            </div>
            
        </div>
    </div>
</div>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
    <div class="bd-overSlide"
        
        
        ><div class=" bd-container-118 bd-tagstyles">
    <a href="http://magnanatura.com/en/produto/unione/" class=" bd-linkbutton-3 bd-button-59 bd-icon-15 bd-content-element"  
 title="UNIONE" rel="prev">
READ MORE
</a>
    <?php
echo <<<'CUSTOM_CODE'

CUSTOM_CODE;
?>
 </div></div>
  </div>
</div></div></div>
</div>
            </div>
        </div>
    </div>
</div>
    </div>
</div>
	
		<div class=" bd-parallaxbackground-1 bd-parallax-bg-effect" data-control-selector=".bd-section-2"><section class=" bd-section-2 bd-page-width bd-section-sheet-align bd-tagstyles" id="section5" data-section-title="Text Block Left on Image">
    <div class="bd-section-inner">
        <div class="bd-section-align-wrapper">
            <div class=" bd-animation-2 animated" data-animation-name="bounceInLeft"
                                    data-animation-event="scroll"
                                    data-animation-duration="2000ms"
                                    data-animation-delay="300ms"
                                    data-animation-infinited="false"
                                    ><div class=" bd-layoutbox-3 clearfix">
    <div class="bd-container-inner">
        <h2 class=" bd-textblock-2 bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
ART &amp; CONCEPT FURNITURE
CUSTOM_CODE;
?>
</h2>
	
		<h1 class=" bd-textblock-4 bd-background-width bd-tagstyles bd-content-element">
    <?php
echo <<<'CUSTOM_CODE'
CORK WOOD SPECIALIST
CUSTOM_CODE;
?>
</h1>
	
		<a href="http://magnanatura.com/en/about-us/" class=" bd-linkbutton-4 bd-button-53 bd-icon-17 bd-content-element"  
 title="Sobre a Magna Natura" rel="next">
about magna natura
</a>
    </div>
</div>
</div>
        </div>
    </div>
</section></div>
	
		<section class=" bd-section-3 bd-tagstyles" id="section4" data-section-title="Three Columns">
    <div class="bd-section-inner">
        <div class="bd-section-align-wrapper">
            <div class=" bd-layoutcontainer-5 bd-background-width">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-animation-4 animated" data-animation-name="bounceInLeft"
                                    data-animation-event="scroll"
                                    data-animation-duration="2200ms"
                                    data-animation-delay="400ms"
                                    data-animation-infinited="false"
                                    ><div class=" bd-layoutcolumn-col-11 
 col-sm-12">
    <div class="bd-layoutcolumn-11"><div class="bd-vertical-align-wrapper"><?php
    ob_start();
    theme_print_sidebar('Area-5', '1_18');
    $current_sidebar_content = trim(ob_get_clean());

    if (isset($theme_hide_sidebar_area)) {
        $theme_hide_sidebar_area = $theme_hide_sidebar_area && !$current_sidebar_content;
    }

    theme_print_sidebar_content($current_sidebar_content, 'Area-5', ' bd-sidebar-18 clearfix');
?></div></div>
</div></div>
	
		<div class=" bd-animation-8 animated" data-animation-name="bounceInRight"
                                    data-animation-event="scroll"
                                    data-animation-duration="2200ms"
                                    data-animation-delay="600ms"
                                    data-animation-infinited="false"
                                    ><div class=" bd-layoutcolumn-col-14 
 col-sm-12">
    <div class="bd-layoutcolumn-14"><div class="bd-vertical-align-wrapper"><div class="bd-imagestyles bd-video-2 ">
    <div class="embed-responsive embed-responsive-16by9">
        

        
            <iframe data-autoplay=false class="embed-responsive-item" src="https://www.youtube.com/embed/QsPSJF4wC-4?loop=0&playlist=&showinfo=1&theme=light&autohide=0&controls=1" frameborder="0" allowfullscreen > </iframe>
    </div>
</div></div></div>
</div></div>
            </div>
        </div>
    </div>
</div>
	
		<div class=" bd-layoutbox-12 bd-background-width clearfix">
    <div class="bd-container-inner">
        
    </div>
</div>
        </div>
    </div>
</section>
	
		<footer class=" bd-footerarea-1">
    <?php if (theme_get_option('theme_override_default_footer_content')): ?>
        <?php echo do_shortcode(theme_get_option('theme_footer_content')); ?>
    <?php else: ?>
        <div class="container  bd-containereffect-7"><div class=" bd-layoutcontainer-4">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-layoutcolumn-col-10 
 col-lg-13
 col-sm-12">
    <div class="bd-layoutcolumn-10"><div class="bd-vertical-align-wrapper"><div class=" bd-animation-1 animated" data-animation-name="flipInX"
                                    data-animation-event="hover"
                                    data-animation-duration="1800ms"
                                    data-animation-delay="100ms"
                                    data-animation-infinited="false"
                                    >
<img class="bd-imagestyles bd-imagelink-1   " src="<?php echo theme_get_image_path('images/98c09ea653b53414164e743a3ef5998e_letras.transp1brancopng.png'); ?>"></div></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-12 
 col-lg-11
 col-sm-12">
    <div class="bd-layoutcolumn-12"><div class="bd-vertical-align-wrapper"><a class="bd-iconlink-22 " href="https://plus.google.com/u/0/107798917843054710988"
 target="_blank"
 title="Google+">
    <span class=" bd-icon-79"></span>
</a>
	
		<a class="bd-iconlink-20 " href="https://www.pinterest.com/magnanatura0361/"
 target="_blank"
 title="Pinterest">
    <span class=" bd-icon-77"></span>
</a>
	
		<a class="bd-iconlink-18 " href="https://www.youtube.com/channel/UCWa72upi2JocGm-8i2YwLpw"
 target="_blank"
 title="Youtube">
    <span class=" bd-icon-75"></span>
</a>
	
		<a class="bd-iconlink-16 " href="https://twitter.com/cork_jewels"
 target="_blank"
 title="Twitter">
    <span class=" bd-icon-71"></span>
</a>
	
		<a class="bd-iconlink-14 " href="https://www.instagram.com/magnanatura/"
 target="_blank"
 title="Instagram">
    <span class=" bd-icon-64"></span>
</a>
	
		<a class="bd-iconlink-12 " href="https://www.facebook.com/MagnaNatura/"
 target="_blank"
 title="Facebook">
    <span class=" bd-icon-62"></span>
</a></div></div>
</div>
            </div>
        </div>
    </div>
</div></div>
	
		<div class="container  bd-containereffect-3"><div class=" bd-layoutcontainer-28">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row
                
                ">
                <div class=" bd-layoutcolumn-col-13 
 col-sm-6">
    <div class="bd-layoutcolumn-13"><div class="bd-vertical-align-wrapper"><?php
    ob_start();
    theme_print_sidebar("footer1", 'footer_2_3');
    $current_sidebar_content = trim(ob_get_clean());

    if (isset($theme_hide_sidebar_area)) {
        $theme_hide_sidebar_area = $theme_hide_sidebar_area && !$current_sidebar_content;
    }

    theme_print_sidebar_content($current_sidebar_content, 'footer1', ' bd-footerwidgetarea-3 clearfix');
?></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-63 
 col-sm-6">
    <div class="bd-layoutcolumn-63"><div class="bd-vertical-align-wrapper"><?php
    ob_start();
    theme_print_sidebar("footer2", 'footer_3_4');
    $current_sidebar_content = trim(ob_get_clean());

    if (isset($theme_hide_sidebar_area)) {
        $theme_hide_sidebar_area = $theme_hide_sidebar_area && !$current_sidebar_content;
    }

    theme_print_sidebar_content($current_sidebar_content, 'footer2', ' bd-footerwidgetarea-4 clearfix');
?></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-64 
 col-sm-6">
    <div class="bd-layoutcolumn-64"><div class="bd-vertical-align-wrapper"><?php
    ob_start();
    theme_print_sidebar("footer3", 'footer_12_6');
    $current_sidebar_content = trim(ob_get_clean());

    if (isset($theme_hide_sidebar_area)) {
        $theme_hide_sidebar_area = $theme_hide_sidebar_area && !$current_sidebar_content;
    }

    theme_print_sidebar_content($current_sidebar_content, 'footer3', ' bd-footerwidgetarea-6 clearfix');
?></div></div>
</div>
	
		<div class=" bd-layoutcolumn-col-15 
 col-sm-6">
    <div class="bd-layoutcolumn-15"><div class="bd-vertical-align-wrapper"><?php
    ob_start();
    theme_print_sidebar('Area-2', '1_17');
    $current_sidebar_content = trim(ob_get_clean());

    if (isset($theme_hide_sidebar_area)) {
        $theme_hide_sidebar_area = $theme_hide_sidebar_area && !$current_sidebar_content;
    }

    theme_print_sidebar_content($current_sidebar_content, 'Area-2', ' bd-sidebar-17 clearfix');
?></div></div>
</div>
            </div>
        </div>
    </div>
</div></div>
	
		<div class=" bd-layoutbox-11 clearfix">
    <div class="bd-container-inner">
        <div class=" bd-pagefooter-2">
    <div class="bd-container-inner">
        <a href ='http://www.billionthemes.com/wordpress_themes' target="_blank">WordPress Theme</a> created with <a href ='http://www.themler.com' target="_blank">Themler</a>.
    </div>
</div>
	
		<a class="bd-imagelink-5  " href="http://www.inovaweb.eu"
 target="_blank"
 title="Inovaweb - Webdesign & Hosting">
<img class=" bd-imagestyles" src="<?php echo theme_get_image_path('images/3fea33f385899164f02fe37a06bfad87_InovawebLogoCinza.png'); ?>">
</a>
	
		<form id="search-4" class=" bd-search-4 form-inline" method="<?php echo isset($_GET['preview']) ? 'post' : 'get'; ?>" name="searchform" action="<?php echo esc_url( home_url() ); ?>/">
    <div class="bd-container-inner">
        <div class="bd-search-wrapper">
            
                <input name="s" type="text" class=" bd-bootstrapinput-3 form-control input-sm" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="Search">
                <a href="#" class=" bd-icon-53" link-disable="true"></a>
        </div>
    </div>
    <input type="hidden" name="post_type" value="<?php echo(!theme_woocommerce_enabled() || theme_get_option('theme_search_mode') == 'post' ? 'post' : 'product'); ?>" />
    <script>
        (function (jQuery, $) {
            jQuery('.bd-search-4 .bd-icon-53').on('click', function (e) {
                e.preventDefault();
                jQuery('#search-4').submit();
            });
        })(window._$, window._$);
    </script>
</form>
    </div>
</div>
    <?php endif; ?>
</footer>
<div id="wp-footer">
    <?php wp_footer(); ?>
    <!-- <?php printf(__('%d queries. %s seconds.', THEME_NS), get_num_queries(), timer_stop(0, 3)); ?> -->
</div>
</body>
</html>