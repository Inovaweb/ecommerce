<?php
/**
* The Template for displaying product archives, including the main shop page which is a post type archive.
*
* @version  2.0.0
*/
theme_load_template('Products', 'products'); ?>