<?php theme_add_template_option('Blog', 'blogTemplate', ''); ?>
<?php theme_add_template_option('Home', 'home', ''); ?>
<?php if (theme_woocommerce_enabled()) theme_add_template_option('Product Overview', 'productOverview', ''); ?>
<?php if (theme_woocommerce_enabled()) theme_add_template_option('Products', 'products', ''); ?>
<?php theme_add_template_option('404', 'template404', '', 0); ?>