<?php
function theme_logo_3(){
?>
<?php
    $logoAlt = get_option('blogname');
    $logoSrc = theme_get_option('theme_logo_url');
    $logoLink = theme_get_option('theme_logo_link');
?>

<a class=" bd-logo-3" href="<?php
    if (!theme_is_empty_html($logoLink)) {
        echo $logoLink;
    } else {
        ?>http://magnanatura.com/en<?php
    }
?>"
 title="Magna Natura - Cork Wood Specialist">
<img class=" bd-imagestyles"<?php
                if (!theme_is_empty_html($logoSrc)) {
                    echo ' src="' . $logoSrc . '"';
                } else {
                    ?>
 src="<?php echo theme_get_image_path('images/f893e0d1538078c9d686875cf1c4cfca_logoAppfc.jpg'); ?>"<?php
                } ?> alt="<?php echo $logoAlt ?>">
</a>
<?php
}