<?php

register_nav_menus(array('top-menu-1' => __('Top Navigation 1', THEME_NS)));

function theme_topmenu_1() {
?>
    
    <div class=" bd-topmenu-1" data-responsive-menu="true">
        
            <div class=" bd-responsivemenu-3 collapse-button">
    <div class="bd-container-inner">
        <div class=" bd-menuitem-13">
            <a  data-toggle="collapse"
                data-target=".bd-topmenu-1 .collapse-button + .navbar-collapse"
                href="#" onclick="return false;">
                    <span></span>
            </a>
        </div>
    </div>
</div>
            <div class="navbar-collapse collapse">
            
            <div class=" bd-horizontalmenu-7 clearfix">
                <div class="bd-container-inner">
                <?php
                    echo theme_get_top_menu(array(
                        'menu' => 'top-menu-1',
                        'theme_location' => 'top-menu-1',
                        'menu_function' => 'theme_topmenu_menu_1_16',
                        'menu_item_start_function' => 'theme_topmenu_menu_item_start_1_14',
                        'menu_item_end_function' => 'theme_topmenu_menu_item_end_1_14',
                        'submenu_item_start_function' => 'theme_topmenu_menu_item_start_1_14',
                        'submenu_item_end_function' => 'theme_topmenu_menu_item_end_1_14'
                    ));
                ?>
                </div>
            </div>
            
        
            </div>
    </div>
    
<?php
}

function theme_topmenu_menu_1_16($content = '') {
    ob_start();
    ?><ul class=" bd-menu-16 nav nav-pills navbar-left">
    <?php echo $content; ?>
</ul><?php
    return ob_get_clean();
}

function theme_topmenu_menu_item_start_1_14($class = '', $title = '', $attrs = '', $link_class='') {
    ob_start();
    ?><li class=" bd-menuitem-14 <?php echo $class; ?>">
    <a class="<?php echo $link_class; ?>" <?php echo $attrs; ?>>
        <span>
            <?php echo $title; ?>
        </span>
    </a><?php
    return ob_get_clean();
}

function theme_topmenu_menu_item_end_1_14() {
    ob_start();
?>
    </li>
    
<?php
    return ob_get_clean();
}

?>