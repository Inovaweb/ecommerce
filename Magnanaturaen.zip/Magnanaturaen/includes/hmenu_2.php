<?php

register_nav_menus(array('primary-menu-2' => __('Primary Navigation ', THEME_NS)));

function theme_hmenu_2() {
?>
    
    <nav class=" bd-hmenu-2" data-responsive-menu="true" data-responsive-levels="">
        
            <div class=" bd-responsivemenu-2 collapse-button">
    <div class="bd-container-inner">
        <div class=" bd-menuitem-2">
            <a  data-toggle="collapse"
                data-target=".bd-hmenu-2 .collapse-button + .navbar-collapse"
                href="#" onclick="return false;">
                    <span>Menu</span>
            </a>
        </div>
    </div>
</div>
            <div class="navbar-collapse collapse">
        
        <div class=" bd-horizontalmenu-5 clearfix">
            <div class="bd-container-inner">
            <?php
                echo theme_get_menu(array(
                    'source' => theme_get_option('theme_menu_source'),
                    'depth' => theme_get_option('theme_menu_depth'),
                    'menu' => 'primary-menu-2',
                    'theme_location' => 'primary-menu-2',
                    'responsive_levels' => '',
                    'levels' => '',
                    'menu_function' => 'theme_menu_2_11',
                    'menu_item_start_function' => 'theme_menu_item_start_2_4',
                    'menu_item_end_function' => 'theme_menu_item_end_2_4',
                    'submenu_start_function' => 'theme_submenu_start_2_13',
                    'submenu_end_function' => 'theme_submenu_end_2_13',
                    'submenu_item_start_function' => 'theme_submenu_item_start_2_11',
                    'submenu_item_end_function' => 'theme_submenu_item_end_2_11'
                ));
            ?>
            </div>
        </div>
        
        
            </div>
    </nav>
    
<?php
}

function theme_menu_2_11($content = '') {
    ob_start();
    ?><ul class=" bd-menu-11 nav nav-pills navbar-left">
    <?php echo $content; ?>
</ul><?php
    return ob_get_clean();
}

function theme_menu_item_start_2_4($class = '', $title = '', $attrs = '', $link_class='') {
    ob_start();
    ?><li class=" bd-menuitem-4 <?php echo $class; ?>">
    <a class="<?php echo $link_class; ?>" <?php echo $attrs; ?>>
        <span>
            <?php echo $title; ?>
        </span>
    </a><?php
    return ob_get_clean();
}

function theme_menu_item_end_2_4() {
    ob_start();
?>
    </li>
    
<?php
    return ob_get_clean();
}

function theme_submenu_start_2_13($class = '') {
    ob_start();
    ?><div class="bd-menu-13-popup">
    <ul class=" bd-menu-13 <?php echo $class; ?>"><?php
    return ob_get_clean();
}

function theme_submenu_end_2_13() {
    ob_start();
?>
        </ul>
    </div>
    
<?php
    return ob_get_clean();
}

function theme_submenu_item_start_2_11($class = '', $title = '', $attrs = '', $link_class = '') {
    ob_start();
    ?><li class=" bd-menuitem-11 <?php echo $class; ?>">
    <a class="<?php echo $link_class; ?>" <?php echo $attrs; ?>>
        <span>
            <?php echo $title; ?>
        </span>
    </a><?php
    return ob_get_clean();
}

function theme_submenu_item_end_2_11() {
    ob_start();
?>
    </li>
    
<?php
    return ob_get_clean();
}